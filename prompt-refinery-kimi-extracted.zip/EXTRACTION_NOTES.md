# Kimi extraction recovery package

This ZIP contains code blocks that were explicitly present in the uploaded Kimi conversation export.

IMPORTANT: Kimi reported that it hit its tool-call budget before completing the project. Therefore this is NOT a complete production-ready backend. It is a recovery of the code that was actually present in the export, plus notes.

Included extracted files:
- src/middleware.ts
- src/app/api/prompts/route.ts
- src/app/api/prompts/[id]/route.ts
- src/app/api/refine/route.ts
- src/app/api/analyze/route.ts
- src/app/api/admin/users/route.ts
- src/app/api/admin/analytics/route.ts
- prisma/seed.ts
- README.md
- src/lib/ai-providers/base.ts
- VERCEL_BUILD_NOTE.txt
- .env.example

Not included because their actual source was not present in the uploaded export: package.json, tsconfig.json, next.config.js, prisma/schema.prisma, src/lib/prisma.ts, src/lib/auth.ts, validators, utilities, provider implementations, prompt templates, refiner implementation, and the remaining API routes.

Use this package as source material for Bolt, not as a ready-to-deploy application.
